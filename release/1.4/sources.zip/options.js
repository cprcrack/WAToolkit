﻿/*
WAToolkit
Author: Cristian Perez <http://www.cpr.name>
License: GNU GPLv3
*/


var whatsAppUrl = "https://web.whatsapp.com/";

window.location.href = whatsAppUrl;
